const http=require('http'),os=require('os'),fs=require('fs'),path=require('path');
const H={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'*','Access-Control-Allow-Methods':'GET,POST,DELETE,OPTIONS','Access-Control-Allow-Private-Network':'true'};
const MIME={'.html':'text/html; charset=utf-8','.js':'application/javascript','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.gif':'image/gif','.webp':'image/webp','.pdf':'application/pdf','.txt':'text/plain; charset=utf-8','.docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document','.wasm':'application/wasm'};
const MAXUP=1024*1024*1024; // 1 جيجا لكل ملف
const safeName=n=>{n=path.basename(String(n||'').replace(/\\/g,'/')).replace(/[\u0000-\u001f<>:"|?*]/g,'_').replace(/^\.+/,'').trim().slice(0,150);return n||('file-'+Date.now())};
const safeRel=n=>{const parts=String(n||'').replace(/\\/g,'/').split('/').map(s=>s.replace(/[\u0000-\u001f<>:"|?*]/g,'_').replace(/^\.+/,'').trim().slice(0,150)).filter(Boolean);return parts.length?parts.slice(0,12).join('/'):('file-'+Date.now())};
const walk=(root,rel,out)=>{let L;try{L=fs.readdirSync(path.join(root,rel),{withFileTypes:true})}catch(e){return}for(const d of L){if(d.name.startsWith('.'))continue;const r=rel?rel+'/'+d.name:d.name;if(d.isDirectory())walk(root,r,out);else if(d.isFile()){try{const st=fs.statSync(path.join(root,r));out.push({name:r,size:st.size,mtime:st.mtimeMs})}catch(e){}}}};
module.exports=function makeServer(ask,ctx){
  ctx=ctx||{};
  const bad=new Map(); // remote ip -> {n, until}
  const share=()=>{const d=ctx.shareDir;if(d&&!fs.existsSync(d))fs.mkdirSync(d,{recursive:true});return d};
  const uniq=(dir,name)=>{let n=name,i=1;const ext=path.extname(name),base=path.basename(name,ext);while(fs.existsSync(path.join(dir,n)))n=base+' ('+(++i)+')'+ext;return n};
  return http.createServer((req,res)=>{
    if(req.method==='OPTIONS'){res.writeHead(204,H);return res.end()}
    const u=new URL(req.url||'/','http://x'),p=u.pathname,ip=req.socket.remoteAddress||'?';
    const send=(code,obj)=>{res.writeHead(code,{...H,'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(obj))};
    const file=(fp,extra)=>{fs.stat(fp,(e,st)=>{if(e||!st.isFile()){res.writeHead(404,H);return res.end()}
      res.writeHead(200,{...H,'Content-Type':MIME[path.extname(fp).toLowerCase()]||'application/octet-stream','Content-Length':st.size,...(extra||{})});fs.createReadStream(fp).pipe(res)})};
    if(p==='/hello')return send(200,{app:'judicial-agenda',name:os.hostname(),v:3,share:!!ctx.shareDir});
    if(req.method==='GET'&&(p==='/'||p==='/m'||p==='/m.html'))return file(path.join(ctx.appDir||__dirname,'mobile.html'),{'Cache-Control':'no-store'});
    if(req.method==='GET'&&p==='/icon.png')return file(path.join(ctx.appDir||__dirname,'icon.png'));
    if(req.method==='GET'&&p.startsWith('/ocr/')){const root=path.join(ctx.appDir||__dirname,'ocr'),fp=path.join(root,p.slice(5));if(!fp.startsWith(root+path.sep))return send(403,{});return file(fp,{'Cache-Control':'public, max-age=86400'})}
    const b=bad.get(ip);if(b&&b.until>Date.now())return send(429,{error:'locked'});
    const fail=()=>{const e=bad.get(ip)||{n:0,until:0};e.n++;if(e.n>=8){e.until=Date.now()+60000;e.n=0}bad.set(ip,e);return send(401,{error:'pin'})};
    const okPin=pin=>{const want=String(ctx.getPin?ctx.getPin():'');return want&&String(pin||'')===want};
    /* ---------- فتح مرفق مباشرة من الكمبيوتر (ثنائي خام، بدون base64) ---------- */
    if(p==='/f/get'&&req.method==='GET'){
      const pin=req.headers['x-pin']||u.searchParams.get('pin');
      if(!okPin(pin))return fail();
      bad.delete(ip);
      Promise.resolve(ask({path:'/file/raw',body:{pin:String(pin),id:u.searchParams.get('id')||''}})).then(r=>{
        if(!r||!r.bin){res.writeHead(404,H);return res.end()}
        const buf=Buffer.from(r.bin);
        res.writeHead(200,{...H,'Content-Type':r.type||'application/octet-stream','Content-Length':buf.length,'Cache-Control':'no-store','X-File-Name':encodeURIComponent(r.name||''),'Access-Control-Expose-Headers':'X-File-Name'});res.end(buf)
      }).catch(()=>{res.writeHead(500,H);res.end()});
      return;
    }
    /* ---------- مشاركة الملفات والمسح (محمية بالكود) ---------- */
    if(p.startsWith('/x/')){
      const pin=req.headers['x-pin']||u.searchParams.get('pin');
      if(!okPin(pin))return fail();
      bad.delete(ip);
      const dir=share();if(!dir)return send(503,{error:'no-share'});
      if(p==='/x/list'&&req.method==='GET'){
        try{const L=[];walk(dir,'',L);L.sort((a,b)=>b.mtime-a.mtime);return send(200,{files:L,name:os.hostname()})}catch(e){return send(500,{error:String(e)})}}
      if(p==='/x/get'&&req.method==='GET'){const n=safeRel(u.searchParams.get('name'));return file(path.join(dir,n),{'Content-Disposition':"attachment; filename*=UTF-8''"+encodeURIComponent(path.basename(n))})}
      if(p==='/x/del'&&(req.method==='POST'||req.method==='DELETE')){const n=safeRel(u.searchParams.get('name'));try{const fp=path.join(dir,n);if(fs.statSync(fp).isDirectory())fs.rmSync(fp,{recursive:true,force:true});else fs.unlinkSync(fp);return send(200,{ok:1})}catch(e){return send(404,{error:'nf'})}}
      if((p==='/x/put'||p==='/x/scan')&&req.method==='POST'){
        const isScan=p==='/x/scan';
        let name=safeRel(u.searchParams.get('name')||(isScan?'scan-'+Date.now()+'.jpg':''));
        const sub=path.dirname(name)==='.'?'':path.dirname(name),base=path.basename(name),sdir=path.join(dir,sub);try{fs.mkdirSync(sdir,{recursive:true})}catch(e){return send(500,{error:String(e)})}
        const nb=u.searchParams.get('overwrite')!=='1'?uniq(sdir,base):base;name=sub?sub+'/'+nb:nb;const tmp=path.join(sdir,'.'+nb+'.part'),ws=fs.createWriteStream(tmp);let size=0,dead=false;
        req.on('data',c=>{size+=c.length;if(size>MAXUP&&!dead){dead=true;req.destroy();ws.destroy();fs.unlink(tmp,()=>{})}});
        req.on('aborted',()=>{ws.destroy();fs.unlink(tmp,()=>{})});
        req.pipe(ws);
        ws.on('finish',()=>{if(dead)return;try{fs.renameSync(tmp,path.join(dir,name))}catch(e){return send(500,{error:String(e)})}
          if(isScan&&typeof ask==='function')Promise.resolve(ask({path:'/scan/new',body:{pin:String(pin),name,from:ip}})).catch(()=>{});
          send(200,{ok:1,name,size})});
        ws.on('error',e=>send(500,{error:String(e)}));
        return;
      }
      return send(404,{});
    }
    /* ---------- المزامنة (كما كانت) ---------- */
    const chunks=[];let size=0,dead=false;
    req.on('data',c=>{size+=c.length;if(size>400*1024*1024){dead=true;req.destroy();return}chunks.push(c)});
    req.on('end',async()=>{
      if(dead)return;
      try{
        const body=chunks.length?JSON.parse(Buffer.concat(chunks).toString('utf8')):{};
        const r=await ask({path:p,body}),st=(r&&r.status)||200;
        if(st===401){const e=bad.get(ip)||{n:0,until:0};e.n++;if(e.n>=8){e.until=Date.now()+60000;e.n=0}bad.set(ip,e)}
        else if(st===200&&bad.has(ip))bad.delete(ip);
        send(st,(r&&r.json)||{});
      }catch(e){send(500,{error:String(e)})}
    });
  });
};
